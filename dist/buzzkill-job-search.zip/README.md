# chrome-extension-buzzkill
A chrome browser extension that removes or redefines job posting buzzwords
